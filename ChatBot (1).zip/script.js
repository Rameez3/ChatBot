
//Generate a random username
function generateRandomUsername() {
  let adjectives = ["Diligent", "Cheerful", "Sunny", "Supreme", "Magnificent"];
  let nouns = ["Daisy", "Sunflower", "Platypus", "Butterfly", "Comet"];
  
  let randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)];
  let randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
  
  let username = randomAdjective + " " + randomNoun;
  
  localStorage.setItem("username", username); // Store the username in localStorage
  
  let greeting = document.getElementById("greeting");
  let appendUsername = document.createTextNode(username);
  
  greeting.appendChild(appendUsername);
}
generateRandomUsername();
