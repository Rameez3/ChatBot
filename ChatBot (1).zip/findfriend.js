var buttons = document.querySelectorAll(".feeling-button");
var selectedItems = [];

buttons.forEach(function(button) {
  button.addEventListener("click", function() {
    this.classList.toggle("highlighted");
    var buttonId = this.id;
    
    var itemIndex = selectedItems.indexOf(buttonId);
    
    if (itemIndex === -1) {
      selectedItems.push(buttonId);
    } else {
      selectedItems.splice(itemIndex, 1);
    }
    
    console.log(selectedItems); // Output the updated array to the console
    matchFriend();
  });
});

function matchFriend() {
  const data = [
    { name: "Magnificient Flower", feelings: "sad, depressed" },
    { name: "Supreme Comet", feelings: "angry, isolated" },
    { name: "Diligent Platypus", feelings: "grief" },
    { name: "Supreme Butterfly", feelings: "anxious" }
  ];

  let maxMatchCount = 0;
  let matchedNames = [];

  data.forEach(item => {
    const feelings = item.feelings.split(", ");
    const matchCount = feelings.filter(feeling => selectedItems.includes(feeling)).length;

    if (matchCount > maxMatchCount) {
      maxMatchCount = matchCount;
      matchedNames = [item.name];
    } else if (matchCount === maxMatchCount) {
      matchedNames.push(item.name);
    }
  });

  if (maxMatchCount > 0) {
    populateFriendsList(matchedNames);
  } else {
    populateFriendsList([]); // Clear the friends list
  }
}

function populateFriendsList(names) {
  var friendsListContainer = document.getElementById("friendsList");
  friendsListContainer.innerHTML = ""; // Clear the existing content

  names.forEach(function(name) {
    var row = document.createElement("div");
    row.classList.add("row");

    var colName = document.createElement("div");
    colName.classList.add("col-8", "font-weight-bold", "friend-name"); // Add "friend-name" class
    colName.textContent = name;

    var colChat = document.createElement("div");
    colChat.classList.add("col-4", "friend-name");
    var chatLink = document.createElement("a");
    chatLink.href = "#";
    chatLink.textContent = "CHAT";
    colChat.appendChild(chatLink);

    row.appendChild(colName);
    row.appendChild(colChat);

    friendsListContainer.appendChild(row);
  });
}


 document.getElementById("sendButton").addEventListener("click", function() {
      sendMessage();
    });

    document.getElementById("message").addEventListener("keyup", function(event) {
      if (event.key === "Enter") {
        sendMessage();
      }
    });

    function sendMessage() {
      var messageInput = document.getElementById("message");
      var message = messageInput.value.trim();

      if (message !== "") {
        var chatContainer = document.querySelector(".chat-container");
        var chatBubble = document.createElement("div");
        chatBubble.classList.add("chat-bubble", "user-bubble");
        chatBubble.textContent = message;

        chatContainer.insertBefore(chatBubble, document.querySelector(".message-input"));

        // Clear the input field
        messageInput.value = "";
      }
    }