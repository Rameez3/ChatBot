apiKey = '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';


// // Set the persona for the conversation
username = localStorage.getItem("username")
persona = `You are a Rogerian psychotherapist. You listen empathetically and provide support. You avoid giving direct advice and encourage the user to explore their feelings. Keep responses brief and speak in the first person like a conversation. Introduce yourself and help me with my mental health. Your name is Riverbot. Do not refer to yourself as a psychotherapist, but instead use pronouns like I. Also, the user name is ${username}`;

// // Initialize the conversation
conversation = [];

const appendChatBubble = (role, content) => {
  const chatBubble = document.createElement('div');
  chatBubble.classList.add('chat-bubble', role);
  chatBubble.innerText = content;
  chatLog.appendChild(chatBubble);
};

// Function to send a message to the chatbot
sendMessage = (message) => {
  return new Promise((resolve, reject) => {
    conversation.push({ role: 'user', content: message });

    try {
      // Send the conversation to the OpenAI API
      fetch('https://api.openai.com/v1/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "text-davinci-003",
          prompt: message,
          max_tokens: 100,
          temperature: 0
        })
      })
      .then(response => response.json())
      .then(data => {
        console.log('API Response:', data);

        // Get the bot's reply
        if (data.choices && data.choices.length > 0) {
          const reply = data.choices[0].text;

          // Add the bot's reply to the conversation
          conversation.push({ role: 'assistant', content: reply });

          resolve(reply); // Return the reply
        } else {
          console.log('Error: Empty response');
          reject(new Error('Empty response'));
        }
      })
      .catch(error => {
        console.log('Error:', error);
        reject(error);
      });
    } catch (error) {
      console.log('Error:', error);
      reject(error);
    }
  });
};


// sendMessage(persona);


const questionInput = document.getElementById('questionInput');
const userBubbleContainer = document.getElementById('userBubbleContainer');
const sendButton = document.getElementById('sendButton');
const chatContainer = document.getElementById('chatContainer');

sendButton.addEventListener('click', () => {
  const question = questionInput.value.trim();

  if (question) {
    const userBubble = createChatBubble(question, 'user-bubble');
    const replyBubble = createChatBubble(sendMessage(question), 'reply-bubble');

    chatContainer.appendChild(userBubble);
    chatContainer.appendChild(replyBubble);
  }

  // Clear the input field
  questionInput.value = '';
});

function createChatBubble(content, bubbleClass) {
  const bubble = document.createElement('div');
  bubble.classList.add('chat-bubble', bubbleClass);
  bubble.innerText = content;
  return bubble;
}







