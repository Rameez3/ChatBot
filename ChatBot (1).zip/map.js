function GetMap() {
  let map = new Microsoft.Maps.Map('#myMap');

  
  // Specify the longitude and latitude for the pin
  var latitude = 30.27484416399985; // Example latitude
  var longitude = -97.74031658958783; // Example longitude

  // Create custom Pushpin at the specified coordinates
   var pin = new Microsoft.Maps.Pushpin(new Microsoft.Maps.Location(latitude, longitude), {
     title: 'Austin Capitol',
   });

  // https://learn.microsoft.com/en-us/bingmaps/v8-web-control/map-control-concepts/pushpins/pushpin-events-example

  // Add the pushpin to the map
   map.entities.push(pin);
  //Creates multiple custom pins at specified coordinates
   var pushpinLocations = [
     { latitude: 30.006080281337706, longitude: -97.852244, title: 'Hill Country MHDD', subtitle: '512-392-8953'},
     { latitude: 30.32929877913526, longitude: -97.71148558650766, title: 'Waterloo Counseling', subtitle: '512-444-9922' },
     { latitude: 30.25573718204942, longitude: -97.74586148650766, title: 'Rock Springs', subtitle: '737-263-2520' },
     { latitude: 30.34411045181852, longitude: -97.71474778465644, title: 'Capital Area Counselling', subtitle: '512-302-1000'},
     { latitude: 30.367076723814638, longitude: -97.70639533631409, title: 'Lone Star Circle of Care', subtitle: '877-800-5722'} ]

  //populates map with custom pins
for (let i = 0; i < pushpinLocations.length; i++) {
    var location = new Microsoft.Maps.Location(pushpinLocations[i].latitude, pushpinLocations[i].longitude);
    var pushpin = new Microsoft.Maps.Pushpin(location, {
      title: pushpinLocations[i].title,
      subTitle: pushpinLocations[i].subtitle
    });
    map.entities.push(pushpin);

    
    





    // Add your post map load code here.
  }
}

addEventListener("DOMContentLoaded", GetMap());